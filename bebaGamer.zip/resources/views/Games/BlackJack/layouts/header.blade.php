
<!-- Metas -->
@yield('metas', View::make('Games.BlackJack.layouts.metas'))

<!-- Scripts -->
@yield('scripts', View::make('Games.BlackJack.layouts.scripts'))

<!-- Fonts -->
@yield('fonts', View::make('Games.BlackJack.layouts.fonts'))

<!-- Styles -->
@yield('styles', View::make('Games.BlackJack.layouts.styles'))

