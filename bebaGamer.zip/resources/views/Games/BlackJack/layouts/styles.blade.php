<link rel="stylesheet" href="{{ asset('storage/Games/BlackJack/css/reset.css')}}" type="text/css">
<link rel="stylesheet" href="{{ asset('storage/Games/BlackJack/css/main.css')}} " type="text/css">
<link rel="stylesheet" href="{{ asset('storage/Games/BlackJack/css/orientation_utils.css')}} " type="text/css">
<link rel="stylesheet" href="{{ asset('storage/Games/BlackJack/css/ios_fullscreen.css')}} " type="text/css">
<link rel='shortcut icon' type='image/x-icon' href="{{ asset('storage/Games/BlackJack/favicon.ico')}}" />