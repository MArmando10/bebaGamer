<link rel="stylesheet" href=" {{ asset('storage/Games/Poker/css/reset.css') }} " type="text/css">
<link rel="stylesheet" href=" {{ asset('storage/Games/Poker/css/main.css') }} " type="text/css">
<link rel="stylesheet" href=" {{ asset('storage/Games/Poker/css/orientation_utils.css') }} " type="text/css">
<link rel="stylesheet" href=" {{ asset('storage/Games/Poker/css/ios_fullscreen.css') }} " type="text/css">
<link rel='shortcut icon' type='image/x-icon' href="{{ asset('storage/Games/Poker/favicon.ico') }}" />