<!-- Metas -->
@yield('metas', View::make('Games.Poker.layouts.metas'))

<!-- Scripts -->
@yield('scripts', View::make('Games.Poker.layouts.scripts'))

<!-- Fonts -->
@yield('fonts', View::make('Games.Poker.layouts.fonts'))

<!-- Styles -->
@yield('styles', View::make('Games.Poker.layouts.styles'))