<link rel="stylesheet" href=" {{ asset('storage/Games/SlotMachine/css/reset.css') }} " type="text/css">
<link rel="stylesheet" href=" {{ asset('storage/Games/SlotMachine/css/main.css') }} " type="text/css">
<link rel="stylesheet" href=" {{ asset('storage/Games/SlotMachine/css/orientation_utils.css') }} " type="text/css">
<link rel="stylesheet" href=" {{ asset('storage/Games/SlotMachine/css/ios_fullscreen.css') }} " type="text/css">
<link rel='shortcut icon' type='image/x-icon' href={{ asset('storage/Games/SlotMachine/favicon.ico') }} />