<!-- Metas -->
@yield('metas', View::make('Games.SlotMachine.layouts.metas'))

<!-- Scripts -->
@yield('scripts', View::make('Games.SlotMachine.layouts.scripts'))

<!-- Fonts -->
@yield('fonts', View::make('Games.SlotMachine.layouts.fonts'))

<!-- Styles -->
@yield('styles', View::make('Games.SlotMachine.layouts.styles'))