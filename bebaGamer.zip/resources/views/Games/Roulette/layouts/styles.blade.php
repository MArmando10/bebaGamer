<link rel="stylesheet" href=" {{ asset('storage/Games/Roulette/css/reset.css') }} " type="text/css">
<link rel="stylesheet" href=" {{ asset('storage/Games/Roulette/css/main.css') }} " type="text/css">
<link rel="stylesheet" href=" {{ asset('storage/Games/Roulette/css/orientation_utils.css') }} " type="text/css">
<link rel="stylesheet" href=" {{ asset('storage/Games/Roulette/css/ios_fullscreen.css') }} " type="text/css">
<link rel='shortcut icon' type='image/x-icon' href="{{ asset('storage/Games/Roulette/css/favicon.ico') }}" />