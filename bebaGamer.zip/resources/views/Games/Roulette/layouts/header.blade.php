<!-- Metas -->
@yield('metas', View::make('Games.Roulette.layouts.metas'))

<!-- Scripts -->
@yield('scripts', View::make('Games.Roulette.layouts.scripts'))

<!-- Fonts -->
@yield('fonts', View::make('Games.Roulette.layouts.fonts'))

<!-- Styles -->
@yield('styles', View::make('Games.Roulette.layouts.styles'))