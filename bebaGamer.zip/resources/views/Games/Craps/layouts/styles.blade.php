<link rel="stylesheet" href="{{ asset('storage/Games/Craps/css/reset.css')}}" type="text/css">
<link rel="stylesheet" href="{{ asset('storage/Games/Craps/css/main.css')}}" type="text/css">
<link rel="stylesheet" href="{{ asset('storage/Games/Craps/css/orientation_utils.css')}}" type="text/css">
<link rel="stylesheet" href="{{ asset('storage/Games/Craps/css/ios_fullscreen.css')}}" type="text/css">
<link rel='shortcut icon' type='image/x-icon' href=' {{ asset('storage/Games/Craps/favicon.ico')}}' />