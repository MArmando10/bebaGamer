<!-- Metas -->
@yield('metas', View::make('Games.Craps.layouts.metas'))

<!-- Scripts -->
@yield('scripts', View::make('Games.Craps.layouts.scripts'))

<!-- Fonts -->
@yield('fonts', View::make('Games.Craps.layouts.fonts'))

<!-- Styles -->
@yield('styles', View::make('Games.Craps.layouts.styles'))