

<?php $__env->startSection('body-config'); ?>
ondragstart="return false;" ondrop="return false;" style="width:100%; background: none;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="background-no-game">
    <div class="" style="position: relative; margin: 10px; overflow: auto; padding: 0">
        <table class="table table-dark">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Anterior</th>
                    <th scope="col">Después</th>
                    <th scope="col">Perdidos</th>
                    <th scope="col">Ganados</th>
                    <th scope="col">Fecha</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $balances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"> <?php echo e($balance->id); ?> </th>
                        <td> <?php echo e($balance->before_credits); ?> </td>
                        <td> <?php echo e($balance->after_credits); ?> </td>
                        <td> <?php echo e($balance->lost_credits); ?> </td>
                        <td> <?php echo e($balance->win_credits); ?> </td>
                        <td> <?php echo e($balance->created_at); ?> </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($balances->links()); ?>

    </div>
</div>

<script>

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\goibet\resources\views/balances.blade.php ENDPATH**/ ?>