<?php if(!$isGame): ?>
    <!-- Metas -->
    <?php echo $__env->yieldContent('metas', View::make('layouts.metas')); ?>

    <!-- Scripts -->
    <?php echo $__env->yieldContent('scripts', View::make('layouts.scripts')); ?>
<?php else: ?>
    <!-- Game Functions -->
    <?php echo $__env->yieldContent('functions', View::make('layouts.functions')); ?>
<?php endif; ?>



<!-- Fonts -->
<?php echo $__env->yieldContent('fonts', View::make('layouts.fonts')); ?>

<!-- Styles -->
<?php echo $__env->yieldContent('styles', View::make('layouts.styles')); ?>
<?php /**PATH C:\laragon\www\bebaGamer\resources\views/layouts/header.blade.php ENDPATH**/ ?>