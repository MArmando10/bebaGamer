

<?php $__env->startSection('extra-header'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->yieldContent('common', View::make('Games.Poker.layouts.header')); ?>
<?php $__env->startSection('body-config'); ?>
ondragstart="return false;" ondrop="return false;" style="width:100%; position: fixed;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div style="">
    <div style="position: fixed; background-color: transparent; top: 0px; left: 0px; width: 100%; height: 100%"></div>
<!-- Functions -->
<?php echo $__env->yieldContent('functions', View::make('Games.Poker.layouts.functions')); ?>
<div class="check-fonts">
    <p class="check-font-1">test 1</p>
</div>

<div>
    <canvas id="canvas" class='ani_hack' width="1700" height="768"> </canvas>
</div>


<div data-orientation="landscape" class="orientation-msg-container">
    <p class="orientation-msg-text">Please rotate your device</p>
</div>
<div id="block_game"
    style="position: fixed; background-color: transparent; top: 0px; left: 0px; width: 100%; height: 100%; display:none">
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\goibet\resources\views/Games/Poker/index.blade.php ENDPATH**/ ?>