<link rel="stylesheet" href="<?php echo e(asset('storage/Games/BlackJack/css/reset.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('storage/Games/BlackJack/css/main.css')); ?> " type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('storage/Games/BlackJack/css/orientation_utils.css')); ?> " type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('storage/Games/BlackJack/css/ios_fullscreen.css')); ?> " type="text/css">
<link rel='shortcut icon' type='image/x-icon' href="<?php echo e(asset('storage/Games/BlackJack/favicon.ico')); ?>" /><?php /**PATH C:\laragon\www\bebaGamer\resources\views/Games/BlackJack/layouts/styles.blade.php ENDPATH**/ ?>