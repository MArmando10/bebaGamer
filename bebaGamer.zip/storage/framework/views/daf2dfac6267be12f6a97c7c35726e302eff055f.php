<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" style="background: linear-gradient(90deg, #101623, #1b2640 100%);">
<head>
    <?php echo $__env->yieldContent('header', View::make('layouts.header', ['isGame' => $isGame])); ?>
    <?php echo $__env->yieldContent('extra-header'); ?>
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
</head>
<body <?php echo $__env->yieldContent('body-config'); ?>>
    <?php if($isGame): ?>
        <?php echo $__env->yieldContent('credits', View::make('layouts.credits')); ?>
    <?php else: ?>
        <?php echo $__env->yieldContent('navigation', View::make('layouts.navigation')); ?>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH C:\laragon\www\bebaGamer\resources\views/layouts/main.blade.php ENDPATH**/ ?>