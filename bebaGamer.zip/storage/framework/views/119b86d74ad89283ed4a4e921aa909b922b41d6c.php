<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/jquery-3.2.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/createjs-2015.11.26.min.js')); ?> "></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/platform.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/ios_fullscreen.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/howler.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/screenfull.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/ctl_utils.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/sprite_lib.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/settings.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CLang.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CPreloader.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CMain.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CTextButton.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CGfxButton.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CToggle.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CMenu.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CGame.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CInterface.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CTweenController.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CSeat.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CFichesController.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CVector2.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CGameSettings.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CEasing.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CHandController.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CCard.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CInsurancePanel.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CGameOver.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CMsgBox.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CCreditsPanel.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CFiche.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('storage/Games/BlackJack/js/CCTLText.js')); ?>"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.6/Chart.bundle.min.js"></script>
<?php /**PATH C:\laragon\www\bebaGamer\resources\views/Games/BlackJack/layouts/scripts.blade.php ENDPATH**/ ?>