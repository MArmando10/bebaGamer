<link rel="stylesheet" href=" <?php echo e(asset('storage/Games/SlotMachine/css/reset.css')); ?> " type="text/css">
<link rel="stylesheet" href=" <?php echo e(asset('storage/Games/SlotMachine/css/main.css')); ?> " type="text/css">
<link rel="stylesheet" href=" <?php echo e(asset('storage/Games/SlotMachine/css/orientation_utils.css')); ?> " type="text/css">
<link rel="stylesheet" href=" <?php echo e(asset('storage/Games/SlotMachine/css/ios_fullscreen.css')); ?> " type="text/css">
<link rel='shortcut icon' type='image/x-icon' href=<?php echo e(asset('storage/Games/SlotMachine/favicon.ico')); ?> /><?php /**PATH C:\laragon\www\bebaGamer\resources\views/Games/SlotMachine/layouts/styles.blade.php ENDPATH**/ ?>