<!-- Metas -->
<?php echo $__env->yieldContent('metas', View::make('Games.Poker.layouts.metas')); ?>

<!-- Scripts -->
<?php echo $__env->yieldContent('scripts', View::make('Games.Poker.layouts.scripts')); ?>

<!-- Fonts -->
<?php echo $__env->yieldContent('fonts', View::make('Games.Poker.layouts.fonts')); ?>

<!-- Styles -->
<?php echo $__env->yieldContent('styles', View::make('Games.Poker.layouts.styles')); ?><?php /**PATH C:\laragon\www\bebaGamer\resources\views/Games/Poker/layouts/header.blade.php ENDPATH**/ ?>