<link rel="stylesheet" href=" <?php echo e(asset('storage/Games/Roulette/css/reset.css')); ?> " type="text/css">
<link rel="stylesheet" href=" <?php echo e(asset('storage/Games/Roulette/css/main.css')); ?> " type="text/css">
<link rel="stylesheet" href=" <?php echo e(asset('storage/Games/Roulette/css/orientation_utils.css')); ?> " type="text/css">
<link rel="stylesheet" href=" <?php echo e(asset('storage/Games/Roulette/css/ios_fullscreen.css')); ?> " type="text/css">
<link rel='shortcut icon' type='image/x-icon' href="<?php echo e(asset('storage/Games/Roulette/css/favicon.ico')); ?>" /><?php /**PATH C:\laragon\www\bebaGamer\resources\views/Games/Roulette/layouts/styles.blade.php ENDPATH**/ ?>