<link rel="stylesheet" href="<?php echo e(asset('storage/Games/Craps/css/reset.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('storage/Games/Craps/css/main.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('storage/Games/Craps/css/orientation_utils.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('storage/Games/Craps/css/ios_fullscreen.css')); ?>" type="text/css">
<link rel='shortcut icon' type='image/x-icon' href=' <?php echo e(asset('storage/Games/Craps/favicon.ico')); ?>' /><?php /**PATH C:\laragon\www\bebaGamer\resources\views/Games/Craps/layouts/styles.blade.php ENDPATH**/ ?>