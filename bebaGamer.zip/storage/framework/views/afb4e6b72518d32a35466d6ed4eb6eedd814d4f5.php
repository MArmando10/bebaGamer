<link rel="stylesheet" href=" <?php echo e(asset('storage/Games/Poker/css/reset.css')); ?> " type="text/css">
<link rel="stylesheet" href=" <?php echo e(asset('storage/Games/Poker/css/main.css')); ?> " type="text/css">
<link rel="stylesheet" href=" <?php echo e(asset('storage/Games/Poker/css/orientation_utils.css')); ?> " type="text/css">
<link rel="stylesheet" href=" <?php echo e(asset('storage/Games/Poker/css/ios_fullscreen.css')); ?> " type="text/css">
<link rel='shortcut icon' type='image/x-icon' href="<?php echo e(asset('storage/Games/Poker/favicon.ico')); ?>" /><?php /**PATH C:\laragon\www\goibet\resources\views/Games/Poker/layouts/styles.blade.php ENDPATH**/ ?>