<!-- Metas -->
<?php echo $__env->yieldContent('metas', View::make('Games.Roulette.layouts.metas')); ?>

<!-- Scripts -->
<?php echo $__env->yieldContent('scripts', View::make('Games.Roulette.layouts.scripts')); ?>

<!-- Fonts -->
<?php echo $__env->yieldContent('fonts', View::make('Games.Roulette.layouts.fonts')); ?>

<!-- Styles -->
<?php echo $__env->yieldContent('styles', View::make('Games.Roulette.layouts.styles')); ?><?php /**PATH C:\laragon\www\bebaGamer\resources\views/Games/Roulette/layouts/header.blade.php ENDPATH**/ ?>