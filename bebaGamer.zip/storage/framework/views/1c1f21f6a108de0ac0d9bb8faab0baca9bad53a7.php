<!-- Metas -->
<?php echo $__env->yieldContent('metas', View::make('Games.SlotMachine.layouts.metas')); ?>

<!-- Scripts -->
<?php echo $__env->yieldContent('scripts', View::make('Games.SlotMachine.layouts.scripts')); ?>

<!-- Fonts -->
<?php echo $__env->yieldContent('fonts', View::make('Games.SlotMachine.layouts.fonts')); ?>

<!-- Styles -->
<?php echo $__env->yieldContent('styles', View::make('Games.SlotMachine.layouts.styles')); ?><?php /**PATH C:\laragon\www\bebaGamer\resources\views/Games/SlotMachine/layouts/header.blade.php ENDPATH**/ ?>