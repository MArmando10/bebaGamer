

<?php $__env->startSection('body-config'); ?>
ondragstart="return false;" ondrop="return false;" style="width:100%; background: none;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="background-no-game">
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\goibet\resources\views/Recharge.blade.php ENDPATH**/ ?>