
<!-- Metas -->
<?php echo $__env->yieldContent('metas', View::make('Games.BlackJack.layouts.metas')); ?>

<!-- Scripts -->
<?php echo $__env->yieldContent('scripts', View::make('Games.BlackJack.layouts.scripts')); ?>

<!-- Fonts -->
<?php echo $__env->yieldContent('fonts', View::make('Games.BlackJack.layouts.fonts')); ?>

<!-- Styles -->
<?php echo $__env->yieldContent('styles', View::make('Games.BlackJack.layouts.styles')); ?>

<?php /**PATH C:\laragon\www\bebaGamer\resources\views/Games/BlackJack/layouts/header.blade.php ENDPATH**/ ?>